# Custom Emoticon

## 介绍

**Custom Emoticon**是一款为Minecraft Java版开发的**自定义表情包**（资源包），它可以让你在聊天框中使用表情包，目前版本内置了10个表情。

## 适用版本
资源包版本：6 <br>
对应Minecraft Java 1.16.2（1.16.2-rc1）~ 1.16.5 <br>
*其余版本未测试

## 使用方法

每个表情的编码从`\ue000`开始，直到`\ue009`结束（Alpha 1.0），通过自定义字体实现，可使用`/tellraw`调用。

>使用示例 <br>
/tellraw @a {"text":"\<user> \ue000"}

`©2023 qiu_yu`